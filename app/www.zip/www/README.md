
<!-- README.md is generated from README.Rmd. Please edit that file -->


Welcome to the `Mouse Brain` project! It is composed of:

-   a [shiny](https://shiny.rstudio.com/) web application,
-   a Bioconductor package at
    [bioconductor.org/packages/spatialLIBD](http://bioconductor.org/packages/spatialLIBD)
    (or from [here](http://research.libd.org/spatialLIBD/)) that lets
    you analyze your data and run a version of their web application

The web application allows you to browse the mouse brain spatial
transcriptomics data generated with
the 10x Genomics Visium platform. Through the [R/Bioconductor
package](https://bioconductor.org/packages/spatialLIBD) you can also
visualize your own datasets using this web application. Please check the
[manuscript](https://doi.org/10.1038/s41593-020-00787-0) or [bioRxiv
pre-print](https://www.biorxiv.org/content/10.1101/2020.02.28.969931v1)
for more details about this project.
